function [d] = sc_compute(X,nbBins_theta,nbBins_r,smallest_r,biggest_r)

% INPUT PARAMETERS:
%     X = set of points
%     nbBins_theta = number of bins in angular dimension
%     nbBins_r = number of bins in radial dimension
%     smallest_r = the smallest radius
%     biggest_r = the biggest radius
% OUTPUT:
%     - d = Shape context descriptor for input points

    X = X';
    n = size(X,1);
    d = cell(n,1);               % Cell to store SC descriptors
    Z = mean2(sqrt(dist2(X,X))); % Normalization factor
       
    % Use log values to avoid vanishing
    minr = log(smallest_r);
    maxr = log(biggest_r);
    dr = (maxr-minr)/nbBins_r;
    r = linspace(minr,maxr-dr,nbBins_r);

    dtheta = 2*pi/nbBins_theta;
    theta = linspace(0,2*pi-dtheta,nbBins_theta);

    % Loop between each sampled point
    for i=1:n
        % Get current point for convenience
        curr_pt = X(i,:);

        % Compute radial distance from current point to the rest
        X_repcurr = repmat(curr_pt,size(X,1),1);
        vec = X_repcurr - X;
        vec(i,:) = [];
        % Compute polar histogram
        [X_theta,X_r] = cart2pol(vec(:,1),vec(:,2));
        distr = [X_theta log(X_r/Z)];
        d{i} = hist3(distr,'Edges',{theta, r});
    end

end