function C = chi2_cost(s1,s2)
% INPUT PARAMETERS:
%     - s1, s2 = Two sets of Shape Context descriptors
% OUTPUT PARAMETERS:
%     - C = Cost matrix for matching the two sets of SC descriptors

    % Obtain descriptors size
    N1 = numel(s1);
    N2 = numel(s2);
    % Initialize cost matrix
    C = zeros(N1,N2);

    % Compute cost for each pair of descriptors using chi^2 test statistic
    for i=1:N1
        for j=1:N2
           cost = 1/2 .* (s1{i}-s2{j}).^2./(s1{i}+s2{j});
           cost(isnan(cost)) = 0;
           C(i,j) = sum(cost,'all');
        end
    end

end
