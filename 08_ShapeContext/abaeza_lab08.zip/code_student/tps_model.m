function [w_x, w_y, E] = tps_model(X,Y,lambda)

    % Compute K matrix, where Kij = U(||(xi,yi)-(xj,yj)||), and U(t) =
    % t^2*log(t^2)
    K = dist2(X,X).*log(dist2(X,X));
    K(isnan(K)) = 0;
    N = size(X,1);
    % Define P
    P = [ones(N,1), X];

    % Create A matrix in Ax = b, where x=[w;a] and b = [v;0]
    A = [K+lambda*eye(N), P; 
         P', zeros(3,3)];
    % Create b vector
    v_x = Y(:,1);
    v_y = Y(:,2);
    % Solve system
    w_x = A\[v_x;0;0;0];
    w_y = A\[v_y;0;0;0];

    omega_x = w_x(1:N);
    omega_y = w_y(1:N);
    % Compute bending energy for x and y coordinates
    E = omega_x'*K*omega_x + omega_y'*K*omega_y;


end