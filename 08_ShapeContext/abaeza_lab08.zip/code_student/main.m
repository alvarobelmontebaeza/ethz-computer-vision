% Load dataset
load('dataset.mat')

% Perform Shape Matching
% Third parameter indicates the visualization flag
shape_matching(objects(1).X, objects(2).X, 1)